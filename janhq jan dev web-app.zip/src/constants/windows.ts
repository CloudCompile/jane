export const windowKey = {
  logsAppWindow: 'logs-app-window',
  logsWindowLocalApiServer: 'logs-window-local-api-server',
  systemMonitorWindow: 'system-monitor-window',
}
